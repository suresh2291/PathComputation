/**
 * 
 */
package com.srmtech.catalist.navigation;

/**
 * @author SRM RI
 *
 */
public class Source2Currentloc {

}
