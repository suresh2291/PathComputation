package com.srmtech.catalist.navigation;

public class CurrentLoc2Product {

}
