package com.srmtech.catalist.navigation;

public class Currentloc2Destination {

}
