package com.srmtech.catalist;

public interface SendJson {
	
		public void sendJsonForNavi(String jsonString);
	
}
