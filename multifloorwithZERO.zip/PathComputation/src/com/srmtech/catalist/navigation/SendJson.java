package com.srmtech.catalist.navigation;

public interface SendJson {
	
		public void sendJsonForNavi(String jsonString);
	
}
